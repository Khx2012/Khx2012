import { useState, useRef, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import InputArea from "./components/InputArea";
import { useJobAgent } from "./hooks/useJobAgent";
import "./App.css";

export default function App() {
  const {
    messages,
    stats,
    currentStage,
    isLoading,
    sendMessage,
  } = useJobAgent();

  return (
    <div className="app">
      <Sidebar currentStage={currentStage} stats={stats} />
      <div className="main">
        <header className="chat-header">
          <div>
            <h2 className="ch-title">Career Agent</h2>
            <p className="ch-sub">Step {currentStage + 1} of 5 — {["Profile intake","Searching job boards","Analyzing matches","Tailoring documents","Drafting outreach"][currentStage]}</p>
          </div>
          <div className="source-pills">
            {["LinkedIn","Indeed","Glassdoor","Careers"].map(s => (
              <span key={s} className="pill on">{s}</span>
            ))}
          </div>
        </header>
        <ChatWindow messages={messages} isLoading={isLoading} />
        <InputArea onSend={sendMessage} isLoading={isLoading} />
      </div>
    </div>
  );
}
