const STAGES = [
  { title: "Profile intake", sub: "Skills & preferences" },
  { title: "Job search", sub: "LinkedIn, Indeed +2" },
  { title: "Match analysis", sub: "Fit scoring" },
  { title: "Tailor documents", sub: "Resume + cover letter" },
  { title: "Outreach", sub: "Recruiter emails" },
];

export default function Sidebar({ currentStage, stats }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo">
          <div className="logo-icon">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 2L10 6H14L11 9L12 13L8 11L4 13L5 9L2 6H6L8 2Z" fill="white" />
            </svg>
          </div>
          <div>
            <h1>JobFinder</h1>
            <p>AI career assistant</p>
          </div>
        </div>
      </div>

      <nav className="stage-list">
        {STAGES.map((stage, i) => (
          <div key={i} className={`stage-item${i === currentStage ? " active" : ""}`}>
            <div className={`stage-dot${i < currentStage ? " done" : i === currentStage ? " current" : ""}`}>
              {i < currentStage ? "✓" : i + 1}
            </div>
            <div className="stage-info">
              <div className="s-title">{stage.title}</div>
              <div className="s-sub">{stage.sub}</div>
            </div>
          </div>
        ))}
      </nav>

      <div className="stats-grid">
        <div className="stat-box"><div className="s-num">{stats.jobs}</div><div className="s-lbl">jobs found</div></div>
        <div className="stat-box"><div className="s-num">{stats.match}</div><div className="s-lbl">top match</div></div>
        <div className="stat-box"><div className="s-num">{stats.tailored}</div><div className="s-lbl">tailored</div></div>
        <div className="stat-box"><div className="s-num">{stats.sent}</div><div className="s-lbl">emails drafted</div></div>
      </div>
    </aside>
  );
}
