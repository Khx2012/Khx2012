export default function JobCard({ job }) {
  const matchNum = parseInt(job.match) || 0;
  const isHigh = matchNum >= 85;

  const handleTailor = () => {
    window.dispatchEvent(new CustomEvent("quickSend", {
      detail: `Tailor my resume and write a cover letter for the ${job.title} role at ${job.company}`
    }));
  };

  const handleEmail = () => {
    window.dispatchEvent(new CustomEvent("quickSend", {
      detail: `Draft a recruiter outreach email for ${job.title} at ${job.company}`
    }));
  };

  return (
    <div className="job-card">
      <div className="jc-top">
        <div>
          <div className="jc-title">{job.title}</div>
          <div className="jc-company">{job.company}</div>
        </div>
        {job.match && (
          <span className={`match-badge ${isHigh ? "" : "med"}`}>{job.match} match</span>
        )}
      </div>

      {(job.location || job.source || job.type) && (
        <div className="jc-meta">
          {job.location && <span className="meta-tag">{job.location}</span>}
          {job.type && <span className="meta-tag">{job.type}</span>}
          {job.source && <span className="meta-tag">{job.source}</span>}
        </div>
      )}

      <div className="jc-actions">
        <button className="jc-btn primary" onClick={handleTailor}>Tailor for this</button>
        <button className="jc-btn" onClick={handleEmail}>Draft email</button>
        {job.url && (
          <a href={job.url} target="_blank" rel="noopener noreferrer" className="jc-btn">
            View job ↗
          </a>
        )}
      </div>
    </div>
  );
}
