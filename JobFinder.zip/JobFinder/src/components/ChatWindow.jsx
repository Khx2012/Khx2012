import { useEffect, useRef } from "react";
import JobCard from "./JobCard";

export default function ChatWindow({ messages, isLoading }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  return (
    <div className="messages">
      {messages.map((msg, i) => (
        <div key={i} className={`msg ${msg.role}`}>
          <div className="msg-avatar">{msg.role === "user" ? "You" : "JA"}</div>
          <div className="msg-body">
            <div className="msg-bubble">
              {msg.type === "jobs" ? (
                <JobCardList jobs={msg.jobs} />
              ) : msg.type === "email" ? (
                <EmailPreview text={msg.content} />
              ) : msg.type === "tailored" ? (
                <TailoredPreview text={msg.content} />
              ) : (
                <span dangerouslySetInnerHTML={{ __html: msg.content.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br/>") }} />
              )}
            </div>
            <div className="msg-time">{msg.time}</div>
          </div>
        </div>
      ))}

      {isLoading && (
        <div className="msg agent">
          <div className="msg-avatar">JA</div>
          <div className="msg-body">
            <div className="typing-indicator">
              <div className="typing-dot" />
              <div className="typing-dot" />
              <div className="typing-dot" />
            </div>
          </div>
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  );
}

function JobCardList({ jobs }) {
  return (
    <>
      <div className="step-tag">✦ job matches found</div>
      <div className="job-cards">
        {jobs.map((job, i) => <JobCard key={i} job={job} />)}
      </div>
    </>
  );
}

function EmailPreview({ text }) {
  return (
    <>
      <div className="step-tag">✦ outreach email drafted</div>
      <div className="cover-preview" dangerouslySetInnerHTML={{ __html: text.replace(/\n/g, "<br/>") }} />
    </>
  );
}

function TailoredPreview({ text }) {
  return (
    <>
      <div className="step-tag">✦ tailored documents ready</div>
      <div dangerouslySetInnerHTML={{ __html: text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br/>") }} />
    </>
  );
}
