import { useState, useRef, useEffect } from "react";

const QUICK_ACTIONS = [
  { label: "Try example profile", text: "I'm a software engineer with 5 years of experience in React and Node.js, looking for a senior frontend role at a startup." },
  { label: "Search PM roles", text: "Search for product manager roles in UAE" },
  { label: "Tailor resume", text: "Tailor my resume for the top match" },
  { label: "Draft emails", text: "Draft outreach emails for the top 3 jobs" },
];

export default function InputArea({ onSend, isLoading }) {
  const [value, setValue] = useState("");
  const textareaRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      setValue(e.detail);
      setTimeout(() => handleSend(e.detail), 50);
    };
    window.addEventListener("quickSend", handler);
    return () => window.removeEventListener("quickSend", handler);
  }, []);

  const handleSend = (text) => {
    const msg = (text || value).trim();
    if (!msg || isLoading) return;
    onSend(msg);
    setValue("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const autoResize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 100) + "px";
  };

  return (
    <div className="input-area">
      <div className="quick-actions">
        {QUICK_ACTIONS.map((qa, i) => (
          <button key={i} className="qa-btn" onClick={() => handleSend(qa.text)}>
            {qa.label}
          </button>
        ))}
      </div>
      <div className="input-row">
        <textarea
          ref={textareaRef}
          className="user-input"
          placeholder="Describe your background, skills, and target role..."
          value={value}
          onChange={(e) => { setValue(e.target.value); autoResize(); }}
          onKeyDown={handleKey}
          rows={1}
        />
        <button className="send-btn" onClick={() => handleSend()} disabled={isLoading || !value.trim()} title="Send">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M2 8L14 2L10 8L14 14L2 8Z" fill="white" />
          </svg>
        </button>
      </div>
    </div>
  );
}
