import { useState, useCallback } from "react";

const SYSTEM_PROMPT = `You are JobFinder, an expert AI job search assistant. Your role is to:

1. PROFILE INTAKE: Collect the user's background — role, skills, years of experience (NEVER suggest changing years of experience), location preference, salary range, and target companies/industries.

2. JOB SEARCH: Search the web for real, current job listings on LinkedIn, Indeed, Glassdoor, and company career pages. Find 3-5 specific, real jobs that match the user's profile.

When listing jobs, format EACH job EXACTLY like this (so the UI can parse it):
1. **[Job Title]**
Company: [Company Name]
Location: [City / Remote]
Type: [Full-time / Part-time / Contract]
Match: [85%]
Source: [LinkedIn / Indeed / Glassdoor]
URL: [apply link if available]
Description: [2 sentence summary]

3. TAILORING: When asked to tailor a resume/cover letter for a specific job:
   - Keep years of experience EXACTLY as stated by the user — never change this
   - Keep core facts (education, companies worked at) unchanged
   - Rephrase skills and bullet points to match the job description's language
   - Add relevant keywords from the job description
   - Write a tailored cover letter (3 paragraphs)

4. OUTREACH EMAILS: Draft professional recruiter outreach emails (150-200 words) that:
   - Reference the specific role and company
   - Highlight 2-3 most relevant skills/achievements
   - Include Subject: line at the top
   - Have a clear call to action

Be proactive — after getting a profile, immediately search for jobs. Keep responses focused and actionable.`;

function parseJobs(text) {
  const jobs = [];
  const blocks = text.split(/\n(?=\d+\.\s+\*\*)/);
  for (const block of blocks) {
    const titleMatch = block.match(/\d+\.\s+\*\*(.*?)\*\*/);
    if (!titleMatch) continue;
    const get = (key) => { const m = block.match(new RegExp(key + ":\\s*(.+)")); return m ? m[1].trim() : ""; };
    jobs.push({
      title: titleMatch[1],
      company: get("Company"),
      location: get("Location"),
      type: get("Type"),
      match: get("Match"),
      source: get("Source"),
      url: get("URL"),
    });
  }
  return jobs.filter(j => j.company);
}

function classifyResponse(text) {
  const lower = text.toLowerCase();
  const jobs = parseJobs(text);
  if (jobs.length >= 2) return { type: "jobs", jobs };
  if (lower.includes("subject:") || (lower.includes("dear ") && lower.includes("hiring"))) return { type: "email" };
  if (lower.includes("cover letter") && text.length > 400) return { type: "tailored" };
  return { type: "text" };
}

function getTime() {
  const now = new Date();
  return now.getHours() + ":" + String(now.getMinutes()).padStart(2, "0");
}

export function useJobAgent() {
  const [messages, setMessages] = useState([{
    role: "agent",
    type: "text",
    content: "Hi! I'm JobFinder, your AI career assistant. I search LinkedIn, Indeed, Glassdoor, and company career pages to find the best matches for you — then tailor your resume and draft outreach emails.\n\nTo get started, tell me your **role**, **key skills**, **years of experience**, and what kind of job you're looking for. You can also paste your existing resume or bio.",
    time: getTime(),
  }]);

  const [stats, setStats] = useState({ jobs: 0, match: "—", tailored: 0, sent: 0 });
  const [currentStage, setCurrentStage] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState([]);

  const sendMessage = useCallback(async (text) => {
    const userMsg = { role: "user", type: "text", content: text, time: getTime() };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    const lower = text.toLowerCase();
    if (lower.includes("search") || lower.includes("find") || lower.includes("job")) {
      setCurrentStage(s => Math.max(s, 1));
    }

    const newHistory = [...history, { role: "user", content: text }];
    setHistory(newHistory);

    try {
      const useSearch = lower.includes("search") || lower.includes("find") || lower.includes("job") || lower.includes("role") || lower.includes("position");

      const body = {
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: newHistory,
        ...(useSearch && { tools: [{ type: "web_search_20250305", name: "web_search" }] }),
      };

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      const fullText = (data.content || []).map(b => b.type === "text" ? b.text : "").filter(Boolean).join("\n");

      const classified = classifyResponse(fullText);
      const agentMsg = { role: "agent", time: getTime(), content: fullText, ...classified };

      setMessages(prev => [...prev, agentMsg]);
      setHistory(prev => [...prev, { role: "assistant", content: fullText }]);

      if (classified.type === "jobs") {
        const topMatch = classified.jobs.reduce((best, j) => (parseInt(j.match) || 0) > (parseInt(best.match) || 0) ? j : best, classified.jobs[0]);
        setStats(s => ({ ...s, jobs: classified.jobs.length, match: topMatch.match || "—" }));
        setCurrentStage(2);
      } else if (classified.type === "tailored") {
        setStats(s => ({ ...s, tailored: s.tailored + 1 }));
        setCurrentStage(3);
      } else if (classified.type === "email") {
        setStats(s => ({ ...s, sent: s.sent + 1 }));
        setCurrentStage(4);
      }

    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: "agent", type: "text", content: "Something went wrong. Please try again.", time: getTime() }]);
    }

    setIsLoading(false);
  }, [history]);

  return { messages, stats, currentStage, isLoading, sendMessage };
}
