# JobFinder 🌟

**AI-powered job search agent** — finds matching jobs across LinkedIn, Indeed, Glassdoor & company career pages, tailors your resume per role, and drafts recruiter outreach emails.

Built with React + Vite and powered by [Claude](https://anthropic.com).

![JobFinder Screenshot](./screenshot.png)

---

## Features

- **Smart job search** — searches LinkedIn, Indeed, Glassdoor, and company career pages in real time
- **Match scoring** — rates each job by fit with your profile
- **Resume tailoring** — rephrases your experience using the job's language and keywords (never changes your years of experience or core facts)
- **Cover letter generation** — writes a custom 3-paragraph cover letter per role
- **Recruiter outreach** — drafts professional 150-200 word cold emails with subject lines
- **5-step progress tracker** — visual sidebar tracks where you are in the job hunt
- **Dark mode support** — auto-adapts to your OS preference

---

## Getting Started

### Prerequisites

- Node.js 18+
- An [Anthropic API key](https://console.anthropic.com)

### Installation

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/JobFinder.git
cd JobFinder

# Install dependencies
npm install

# Set up your API key
cp .env.example .env
# Edit .env and add your Anthropic API key

# Start the dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## Usage

1. **Describe yourself** — tell the agent your role, skills, years of experience, location, and what you're looking for
2. **Get job matches** — the agent searches real job boards and returns 3-5 ranked matches
3. **Tailor your docs** — click "Tailor for this" on any job card to get a customized resume + cover letter
4. **Draft outreach** — click "Draft email" to get a recruiter cold email ready to send

### Example prompts

- *"I'm a data scientist with 4 years of experience in Python and machine learning, looking for senior roles at climate tech companies in London or remote"*
- *"Search for UX designer jobs in Dubai"*
- *"Tailor my resume for the product manager role at Noon"*
- *"Draft a recruiter outreach email for the senior engineer position at Careem"*

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite |
| AI | Claude claude-sonnet-4-20250514 (Anthropic) |
| Job Search | Claude web search tool (real-time) |
| Styling | Plain CSS with CSS variables |
| Fonts | DM Sans + DM Mono |

---

## Project Structure

```
JobFinder/
├── src/
│   ├── components/
│   │   ├── Sidebar.jsx       # Progress tracker + stats
│   │   ├── ChatWindow.jsx    # Message list + job cards
│   │   ├── JobCard.jsx       # Individual job result card
│   │   └── InputArea.jsx     # Text input + quick actions
│   ├── hooks/
│   │   └── useJobAgent.js    # Core agent logic + Anthropic API calls
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── vite.config.js
├── package.json
└── .env.example
```

---

## Deploying

### Vercel (recommended)

```bash
npm install -g vercel
vercel
# Add VITE_ANTHROPIC_API_KEY in Vercel dashboard → Settings → Environment Variables
```

### Netlify

```bash
npm run build
# Drag the dist/ folder to netlify.com/drop
# Add VITE_ANTHROPIC_API_KEY in Site settings → Environment variables
```

> **Security note:** This project calls the Anthropic API directly from the browser for simplicity. For a production app, proxy requests through your own backend to keep your API key private.

---

## Roadmap

- [ ] Backend proxy server (Express/Next.js) for secure API key handling
- [ ] Browser automation for true 1-click apply (Playwright)
- [ ] PDF resume upload + parsing
- [ ] Save & track applications
- [ ] Email integration (send outreach directly from the app)
- [ ] Interview prep module

---

## Contributing

Pull requests welcome! Please open an issue first to discuss major changes.

1. Fork the repo
2. Create your branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m 'Add some feature'`
4. Push to the branch: `git push origin feature/your-feature`
5. Open a pull request

---

## License

MIT © [Your Name](https://github.com/YOUR_USERNAME)

---

*Built with Claude by Anthropic*
